INSERT INTO `sta_status_dictionary` (status_name, status_info) VALUES ('在职','员工在职工作');
INSERT INTO `sta_status_dictionary` (status_name, status_info) VALUES ('退休','员工退休');
INSERT INTO `sta_status_dictionary` (status_name, status_info) VALUES ('革职','员工被革职');
INSERT INTO `sta_status_dictionary` (status_name, status_info) VALUES ('休假','员工前往休假');
COMMIT;